export interface LoginUserDTO {
    email: string;
    password: string;
}