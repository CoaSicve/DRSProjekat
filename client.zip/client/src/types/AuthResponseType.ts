export type AuthResponseType = {
    success: boolean;
    message?: string;
    token?: string;
}