export type AuthTokenClaimsType = {
  id: number;
  email: string;
  role: string;
};