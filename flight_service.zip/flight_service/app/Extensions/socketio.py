from flask_socketio import SocketIO

socketio = SocketIO()