from app import create_app
from app.Extensions.socketio import socketio

app = create_app()